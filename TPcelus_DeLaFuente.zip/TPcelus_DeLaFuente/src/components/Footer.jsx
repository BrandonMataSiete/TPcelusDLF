function Footer() {
    return (
      <footer style={{ textAlign: 'center', padding: '1rem', backgroundColor: '#333', color: 'white' }}>
        © 2025 - Sitio de Celulares
      </footer>
    )
  }
  
  export default Footer;
  